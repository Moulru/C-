#include <iostream>
using namespace std;

template <class T> class Array {
	//	template <typename T> class Array �� �����ڵ�
protected:
	T* m_arr;
	int m_maxSize;
	int m_curSize;
public:
	Array(int size = 5) {
		m_maxSize = size;
		m_curSize = 0;
		m_arr = new T[size];
	}
	~Array() {
		delete[] m_arr;
	}

	void Add(int data) {
		if (m_curSize >= m_maxSize) {
			T* tmp = m_arr;
			m_maxSize += 5;
			m_arr = new T[m_maxSize];
			for (int i = 0; i < m_curSize; i++) {
				m_arr[i] = tmp[i];
			}
			delete[] tmp;
		}
		m_arr[m_curSize] = data;
		m_curSize++;
	}

	bool GetAt(int index, T& data) {
		if (index<0 || index>m_curSize) {
			return false;
		}
		data = m_arr[index];
		return true;
	}

	bool SetAt(int index, T data) {
		if (index<0 || index>m_curSize) {
			return false;
		}
		m_arr[index] = data;
		return true;
	}

	int GetSize() {
		return m_curSize;
	}
};

int main() {
	Array<int> arr;
	int num;
	cout << "������ �Է��ϼ���(-1�̸� ����) : ";
	cin >> num;
	while (num != -1) {
		arr.Add(num);
		cout << "������ �Է��ϼ���(-1�̸� ����) : ";
		cin >> num;
	}
	cout << "�Էµ� ���� : ";
	for (int i = 0; i < arr.GetSize(); i++) {
		int data;
		arr.GetAt(i, data);
		cout << data << " ";
	}
	cout << endl;
	system("PAUSE");
	return 0;
}