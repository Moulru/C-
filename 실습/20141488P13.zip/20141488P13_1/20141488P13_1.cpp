#include <iostream>
using namespace std;

int main() {
	cout << 123.23 << " hello " << 100 << endl;
	cout << 10 << ' ' << -10 << endl;
	cout << 100.0 << endl << endl;

	cout.unsetf(ios::dec);
	cout.setf(ios::hex);
	cout.setf(ios::scientific);

	cout << 123.23 << " hello " << 100 << endl;
	cout.setf(ios::showpos);
	cout << 10 << ' ' << -10 << endl;
	cout.unsetf(ios::scientific);
	cout.setf(ios::showpoint | ios::fixed);
	cout << 100.0 << endl << endl;

	cout.setf(ios::uppercase | ios::showbase);
	cout.setf(ios::hex);
	cout << 88 << endl;
	cout.unsetf(ios::uppercase);
	cout << 88 << endl << endl;
	cout.unsetf(ios::showpos | ios::showpoint | ios::fixed);

	cout.width(10);
	cout << "Hello" << endl;
	cout.fill('#');
	cout.setf(ios::left);
	cout.width(10);
	cout << "Hello" << endl;
	cout.width(10);
	cout.precision(8);
	cout << 123.230045 << endl;
	cout.width(10);
	cout.precision(6);
	cout << 0.003456789 << endl;

	system("PAUSE");
	return 0;
}