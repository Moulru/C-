#include <iostream>
using namespace std;

class Circle {
	int m_radius;
public:
	Circle(int radius);
	double Get_Area();
};

Circle::Circle(int radius) {
	m_radius = radius;
}

double Circle::Get_Area() {
	return 3.14 * m_radius * m_radius;
}

int main() {
	Circle ob[4] = { 1,2,3,4 };
	Circle *p;
	p = ob;
	
	cout << "��ü�� ��� �Լ� ����" << endl;
	for (int i = 0; i < 4; i++) {
		cout << ob[i].Get_Area() << " ";
	}
	cout << endl;

	cout << "��ü �����ͷ� ��� �Լ� ����" << endl;
	for (int i = 0; i < 4; i++) {
		cout << p->Get_Area() << " ";
		p++;
	}

	system("PAUSE");
	return 0;
}