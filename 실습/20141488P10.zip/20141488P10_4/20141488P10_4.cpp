#include <iostream>
#include <string>
using namespace std;

class Dogs {
	string m_breed;
protected:
	int m_year;
public:
	Dogs(string breed, int year) {
		m_breed = breed;
		m_year = year;
	}
	string Get_Breed() {
		return m_breed;
	}
};

class Name {
protected:
	string m_name;
	string m_parent;
	char m_gender;
	void Show_Name();
public:
	Name(string name, string parent, char gender) {
		m_name = name;
		m_parent = parent;
		m_gender = gender;
	}
};

void Name::Show_Name() {
	cout << "�� �� : " << m_name << endl;
}

class PetDogs :public Dogs, protected Name {
	double m_weight;
	int m_lifeyear;
public:
	PetDogs(string breed, int year, string name, string parent, char gender, double weight, int lifeyear) :Dogs(breed, year), Name(name, parent, gender) {
		m_weight = weight;
		m_lifeyear = lifeyear;
	}
	void Show_Pet();
};

void PetDogs::Show_Pet() {
	string gender_type[2] = { "����","����" };
	cout << "ǰ �� : " << Get_Breed() << endl;
	cout << "�� �� : " << m_year << "��\n";
	Show_Name();
	cout << "�� �� : ";
	switch (m_gender) {
	case 'F':
		cout << gender_type[0] << endl;
		break;
	case 'M':
		cout << gender_type[1] << endl;
		break;
	}
	cout << "��ռ��� : " << m_lifeyear << "��\n";
	cout << "�� �� : " << m_parent << endl;
	cout << "������ : " << m_weight << "Kg\n";
}

int main() {
	PetDogs pug("�۱�", 4, "�۱���", "�۾�+�۳�", 'M', 2.5, 13);

	pug.Show_Pet();
	system("PAUSE");
	return 0;
}