#include <iostream> 
using namespace std;

class Student {
	int m_score;
public:
	Student(int score) {
		m_score = score;
	}
	int Get_Score() {
		return m_score;
	}
};

int Square_Score(Student ob) {
	return (ob.Get_Score() * ob.Get_Score());
}

int main() {
	Student kim(50);
	cout << "���� = " << kim.Get_Score() << endl;
	cout << "���� ���� = " << Square_Score(kim) << endl;

	system("PAUSE");
	return 0;
}