﻿#include <iostream>
using namespace std;

int main()
{
	char name[20];
	cout << "이름을 입력하세요 : ";
	cin >> name;
	cout << name << "학생, 프로그램 세계에 온 것을 환영합니다!" << endl;

	return 0;

}