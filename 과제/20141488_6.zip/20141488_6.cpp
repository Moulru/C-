#include <iostream>
#include <math.h>
using namespace std;

class CPoint {
protected:
	double m_x, m_y;
public:
	CPoint() {}
	CPoint(double x, double y);
	virtual double Compute_Unit() = 0;
	virtual void Print_Point();
};

CPoint::CPoint(double x, double y) {
	m_x = x;
	m_y = y;
}

void CPoint::Print_Point() {
	cout << "x: " << m_x << ", y: " << m_y;
}

class CLengthPoint : public CPoint {
	double m_z;
public:
	CLengthPoint() {}
	CLengthPoint(double x, double y, double z) : CPoint(x, y) {
		m_z = z;
	}
	virtual double Compute_Unit();
	virtual void Print_Point();
};

double CLengthPoint::Compute_Unit() {
	return sqrt((m_x*m_x) + (m_y*m_y) + (m_z*m_z));
}

void CLengthPoint::Print_Point() {
	CPoint::Print_Point();
	cout << ", z: " << m_z;
}

class CVoulmePoint : public CPoint {
protected:
	double m_z;
public:
	CVoulmePoint() {}
	CVoulmePoint(double x, double y, double z) : CPoint(x, y) {
		m_z = z;
	}
	virtual double Compute_Unit();
	virtual void Print_Point();
};

double CVoulmePoint::Compute_Unit() {
	return m_x*m_y*m_z;
}

void CVoulmePoint::Print_Point() {
	CPoint::Print_Point();
	cout << ", z: " << m_z;
}

class CAreaPoint : public CVoulmePoint {
public:
	CAreaPoint() {}
	CAreaPoint(double x, double y, double z) {
		m_x = x;
		m_y = y;
		m_z = z;
	}
	virtual double Compute_Unit();
};

double CAreaPoint::Compute_Unit() {
	return (2 * ((m_x*m_y) + (m_y*m_z) + (m_z*m_x)));
}

int main() {
	CPoint *p;
	CLengthPoint obj1(5.7,12.5,3.4);
	CVoulmePoint obj2(11.6,4.1,5.4);
	CAreaPoint obj3(3.7,8.9,4.5);
	
	cout.setf(ios::fixed, ios::floatfield);
	cout.precision(1);

	p = &obj1;
	cout << "��ü lengthP*�� ��ǥ : ";
	p->Print_Point();
	cout << endl;
	cout << "��ü lengthP*�� �������κ����� �Ÿ� : " << p->Compute_Unit() << endl;
	
	p = &obj2;
	cout << "��ü volumeP*�� ��ǥ : ";
	p->Print_Point();
	cout << endl;
	cout << "��ü volumeP*�� ����ü ���� : " << p->Compute_Unit() << endl;

	p = &obj3;
	cout << "��ü areaP*�� ��ǥ : ";
	p->Print_Point();
	cout << endl;
	cout << "��ü areaP*�� ����ü �ѳ��� : " << p->Compute_Unit() << endl;

	system("PAUSE");
	return 0;
}