#include <iostream>
#include <string>
using namespace std;

class MyTime {
	int m_hour;
	int m_min;
public:
	MyTime(int min = 0);
	MyTime(int hour, int min);
	MyTime operator+(MyTime t);
	friend MyTime operator+(MyTime t, int min);
	MyTime operator-(int min);
	friend MyTime operator-(MyTime t1, MyTime t2);
	MyTime operator*(double k);
	friend MyTime operator*(double k, MyTime t);
	MyTime operator=(MyTime t);
	friend int operator>(MyTime t1, MyTime t2);
	void Print_Time(string obj);
	friend int Compute_Total_Mins(MyTime t);
	MyTime Make_Time_Object(int min);
};

MyTime::MyTime(int min) {
	m_hour = 0;
	if (min < 0) {
		m_min = 0;
	}
	else {
		while (min >= 60) {
			min -= 60;
			m_hour++;
		}
		m_min = min;
	}
}
MyTime::MyTime(int hour, int min) {
	if (hour < 0 || min < 0) {
		m_hour = 0;
		m_min = 0;
	}
	else {
		m_hour = hour;
		while (min >= 60) {
			min -= 60;
			m_hour++;
		}
		m_min = min;
	}
}

MyTime MyTime::operator+(MyTime t) {
	MyTime tmp;
	tmp.m_min = Make_Time_Object(m_min + t.m_min).m_min;
	tmp.m_hour = m_hour + t.m_hour + Make_Time_Object(m_min + t.m_min).m_hour;

	return tmp;
}
MyTime operator+(MyTime t, int min) {
	MyTime tmp;
	tmp.m_hour = t.m_hour + tmp.Make_Time_Object(min).m_hour;
	tmp.m_min = t.m_min + tmp.Make_Time_Object(min).m_min;
	return tmp;
}

MyTime MyTime::operator-(int min) {
	int check = Compute_Total_Mins(*this)-min;
	if (check < 0) {
		MyTime tmp;
		tmp.m_hour = 0;
		tmp.m_min = 0;
		return tmp;
	}
	else {
		int res_tmp_time = Compute_Total_Mins(*this) - min;
		MyTime tmp(res_tmp_time);
		return tmp;
	}
}
MyTime operator-(MyTime t1, MyTime t2) {
	int res_tmp_time = Compute_Total_Mins(t1) - Compute_Total_Mins(t2);
	if (res_tmp_time < 0) {
		res_tmp_time = 0;
	}
	MyTime tmp(res_tmp_time);
	return tmp;
}

MyTime MyTime::operator*(double k) {
	MyTime tmp((int)(Compute_Total_Mins(*this) * k));
	return tmp;
}
MyTime operator*(double k, MyTime t) {
	MyTime tmp((int)(Compute_Total_Mins(t) * k));
	return tmp;
}

MyTime MyTime::operator=(MyTime t) {
	m_hour = t.m_hour;
	m_min = t.m_min;

	return *this;
}

int operator>(MyTime t1, MyTime t2) {
	
	if (Compute_Total_Mins(t1) > Compute_Total_Mins(t2))
	{
		return 1;
	}
	else if (Compute_Total_Mins(t1) < Compute_Total_Mins(t2))
	{
		return -1;
	}
	else return 0;
}

void MyTime::Print_Time(string obj) {
	if (Compute_Total_Mins(*this) < 60) {
		cout << obj << " : " << m_min << "��" << endl;
	} else cout << obj << " : " << m_hour << "�ð� " << m_min << "��" << endl;
}

int Compute_Total_Mins(MyTime t) {
	return t.m_hour*60 + t.m_min;
}

MyTime MyTime::Make_Time_Object(int min) {
	MyTime tmp;
	tmp.m_hour = 0;
	while (min >= 60) {
		min -= 60;
		tmp.m_hour++;
	}
	tmp.m_min = min;

	return tmp;
}

int main() {
	MyTime ob1(135);
	MyTime ob2(2, 90);
	MyTime ob3(3, -30);
	MyTime result;

	ob1.Print_Time("ob1");
	ob2.Print_Time("ob2");
	ob3.Print_Time("ob3");

	cout << "ob1�� total mins : "<< Compute_Total_Mins(ob1) << "��" << endl;
	cout << "ob2�� total mins : " << Compute_Total_Mins(ob2) << "��" << endl;

	result = ob1 + ob2;
	result.Print_Time("ob1 + ob2");

	result = ob1 + 80;
	result.Print_Time("ob1 + 80");

	result = ob1 - ob2;
	result.Print_Time("ob1 - ob2");

	result = ob2 - ob1;
	result.Print_Time("ob2 - ob1");

	result = ob1 - 45;
	result.Print_Time("ob1 - 45");

	result = ob2 * 10;
	result.Print_Time("ob2 * 10");

	result = 3.75 * ob2;
	result.Print_Time("3.75 * ob2");

	switch (ob1 > ob2)
	{
	case -1:
		cout << "ob1�� �ð��� ob2���� �۽��ϴ�" << endl;
		break;
	case 0:
		cout << "ob1�� �ð��� ob2�� �����ϴ�" << endl;
		break;
	case 1:
		cout << "ob1�� �ð��� ob2���� Ů�ϴ�" << endl;
		break;
	default:
		break;
	}

	result = ob1 = ob2;
	result.Print_Time("ob1=ob2");

	switch (ob1 > ob2)
	{
	case -1:
		cout << "ob1�� �ð��� ob2���� �۽��ϴ�" << endl;
		break;
	case 0:
		cout << "ob1�� �ð��� ob2�� �����ϴ�" << endl;
		break;
	case 1:
		cout << "ob1�� �ð��� ob2���� Ů�ϴ�" << endl;
		break;
	default:
		break;
	}
}